# 🎭 StickerBot — стикерпак и эмодзи-комбо из фото

## Что умеет
- **Стикерпак из фото** — rembg вырезает объект, делает PNG стикеры 512x512
- **Эмодзи-комбо** — Stable Diffusion (Replicate) генерирует необычные эмодзи
- **Freemium** — 3 стикера/день и 5 эмодзи/день бесплатно
- **Оплата Stars** — Telegram Stars встроенная оплата

## Быстрый старт

### 1. Переменные окружения

```
BOT_TOKEN=твой_токен_от_BotFather
REPLICATE_API_TOKEN=твой_токен_replicate
BOT_USERNAME=имя_бота_без_@
```

### 2. Локальный запуск

```bash
pip install -r requirements.txt
python bot.py
```

### 3. Деплой на Render

1. Залей на GitHub
2. Render → New → Background Worker
3. Укажи переменные окружения
4. Deploy!

> ⚠️ Render Free tier усыпляет воркер через 15 минут неактивности.  
> Для продакшна используй **Render Starter** ($7/мес) или **Railway**.

## Команды бота

| Команда | Описание |
|---|---|
| /start | Главное меню |
| /emoji 🕯️ + 🦩 | Слияние двух эмодзи |
| /emoji_random | Случайная необычная комбинация |
| /premium | Магазин Premium |
| /stats | Статистика использования |

## Freemium логика

| Функция | Бесплатно | Премиум |
|---|---|---|
| Стикеры | 3/день | 50/день HD |
| Эмодзи | 5/день | Безлимит |
| Стили | Нет | 5 стилей |
| Качество | Стандарт | HD |

## Цены (Telegram Stars)

- 🎭 Полный стикерпак — **50 ⭐**
- ✨ Эмодзи безлимит (30д) — **30 ⭐**
- 🌟 Полный Премиум (30д) — **75 ⭐**

## Структура проекта

```
stickerbot/
├── bot.py              # Точка входа
├── config.py           # Конфиг
├── requirements.txt
├── render.yaml         # Деплой конфиг
├── handlers/
│   ├── start.py        # /start и меню
│   ├── stickers.py     # Обработка фото → стикеры
│   ├── emoji_combo.py  # /emoji команды
│   └── payment.py      # Stars оплата
├── services/
│   ├── sticker_service.py  # rembg логика
│   └── emoji_service.py    # Replicate API
└── database/
    └── db.py           # SQLite, пользователи, лимиты
```
