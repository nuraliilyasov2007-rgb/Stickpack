import aiosqlite
import logging
from datetime import date

logger = logging.getLogger(__name__)
DB_PATH = "stickerbot.db"


async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id     INTEGER PRIMARY KEY,
                username    TEXT,
                first_name  TEXT,
                created_at  TEXT DEFAULT (date('now')),
                is_premium  INTEGER DEFAULT 0,
                premium_until TEXT
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS daily_usage (
                user_id     INTEGER,
                usage_date  TEXT,
                stickers_used INTEGER DEFAULT 0,
                emoji_used    INTEGER DEFAULT 0,
                PRIMARY KEY (user_id, usage_date)
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS payments (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id     INTEGER,
                product     TEXT,
                stars_amount INTEGER,
                paid_at     TEXT DEFAULT (datetime('now'))
            )
        """)
        await db.commit()
    logger.info("Таблицы созданы/проверены")


async def get_or_create_user(user_id: int, username: str, first_name: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            INSERT OR IGNORE INTO users (user_id, username, first_name)
            VALUES (?, ?, ?)
        """, (user_id, username, first_name))
        await db.commit()

        async with db.execute(
            "SELECT * FROM users WHERE user_id = ?", (user_id,)
        ) as cursor:
            row = await cursor.fetchone()
            return row


async def get_today_usage(user_id: int) -> dict:
    today = date.today().isoformat()
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT stickers_used, emoji_used FROM daily_usage WHERE user_id = ? AND usage_date = ?",
            (user_id, today)
        ) as cursor:
            row = await cursor.fetchone()
            if row:
                return {"stickers": row[0], "emoji": row[1]}
            return {"stickers": 0, "emoji": 0}


async def increment_usage(user_id: int, field: str):
    today = date.today().isoformat()
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(f"""
            INSERT INTO daily_usage (user_id, usage_date, {field})
            VALUES (?, ?, 1)
            ON CONFLICT(user_id, usage_date)
            DO UPDATE SET {field} = {field} + 1
        """, (user_id, today))
        await db.commit()


async def is_premium(user_id: int) -> bool:
    today = date.today().isoformat()
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT premium_until FROM users WHERE user_id = ?", (user_id,)
        ) as cursor:
            row = await cursor.fetchone()
            if row and row[0] and row[0] >= today:
                return True
            return False


async def set_premium(user_id: int, days: int = 30):
    from datetime import date, timedelta
    until = (date.today() + timedelta(days=days)).isoformat()
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE users SET is_premium = 1, premium_until = ? WHERE user_id = ?",
            (until, user_id)
        )
        await db.commit()


async def log_payment(user_id: int, product: str, stars: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO payments (user_id, product, stars_amount) VALUES (?, ?, ?)",
            (user_id, product, stars)
        )
        await db.commit()
