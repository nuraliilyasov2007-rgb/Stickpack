import os
from dataclasses import dataclass


@dataclass
class Config:
    BOT_TOKEN: str = os.getenv("BOT_TOKEN", "")
    REPLICATE_API_TOKEN: str = os.getenv("REPLICATE_API_TOKEN", "")
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///stickerbot.db")

    # Freemium лимиты
    FREE_STICKERS_PER_DAY: int = 3
    FREE_EMOJI_PER_DAY: int = 5

    # Цены в Telegram Stars
    PRICE_FULL_PACK: int = 50        # полный стикерпак (до 50 шт)
    PRICE_EMOJI_UNLIMITED: int = 30  # безлимит эмодзи на 30 дней
    PRICE_HD_QUALITY: int = 25       # HD вырезка

    # Telegram
    BOT_USERNAME: str = os.getenv("BOT_USERNAME", "")


config = Config()
