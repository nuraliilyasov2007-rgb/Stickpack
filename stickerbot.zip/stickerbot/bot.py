import asyncio
import logging
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage

from config import config
from database.db import init_db
from handlers import start, stickers, emoji_combo, payment

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


async def main():
    bot = Bot(token=config.BOT_TOKEN)
    dp = Dispatcher(storage=MemoryStorage())

    # Регистрируем роутеры
    dp.include_router(start.router)
    dp.include_router(stickers.router)
    dp.include_router(emoji_combo.router)
    dp.include_router(payment.router)

    await init_db()
    logger.info("БД инициализирована")

    await bot.delete_webhook(drop_pending_updates=True)
    logger.info("Бот запущен!")

    try:
        await dp.start_polling(bot)
    finally:
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
