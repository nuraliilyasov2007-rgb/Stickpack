import httpx
import asyncio
import logging
import random
from config import config

logger = logging.getLogger(__name__)

# Необычные комбинации для вдохновения
UNUSUAL_COMBOS = [
    ("🕯️", "канделябр", "chandelier with candles, ornate gothic style"),
    ("🦩", "фламинго", "flamingo standing on one leg, elegant"),
    ("🌊", "волна", "ocean wave crashing, dramatic"),
    ("🍄", "гриб", "mushroom with glowing spores, magical forest"),
    ("🦋", "бабочка", "butterfly with iridescent wings, ethereal"),
    ("🌙", "луна", "crescent moon with stars, night sky"),
    ("🔮", "шар", "crystal ball with swirling mist inside"),
    ("🐙", "осьминог", "octopus with tentacles spread, deep ocean"),
    ("🌺", "цветок", "tropical flower blooming, vibrant colors"),
    ("⚡", "молния", "lightning bolt striking, dramatic effect"),
]

# Стили для генерации эмодзи
EMOJI_STYLES = [
    "emoji style, flat design, vibrant colors, white background, simple",
    "sticker style, cute kawaii, thick outline, pastel colors",
    "neon glow effect, dark background, cyberpunk style",
    "watercolor style, soft edges, artistic, transparent background",
    "3D render, glossy, cartoon style, studio lighting",
]


async def generate_emoji_combo(prompt: str, style_index: int = 0) -> str | None:
    """
    Генерирует эмодзи-картинку через Replicate SD.
    Возвращает URL готовой картинки.
    """
    style = EMOJI_STYLES[style_index % len(EMOJI_STYLES)]
    full_prompt = f"{prompt}, {style}, high quality"

    headers = {
        "Authorization": f"Token {config.REPLICATE_API_TOKEN}",
        "Content-Type": "application/json",
    }

    # Используем flux-dev — быстро и качественно
    payload = {
        "version": "black-forest-labs/flux-dev",
        "input": {
            "prompt": full_prompt,
            "width": 512,
            "height": 512,
            "num_outputs": 1,
            "num_inference_steps": 28,
            "guidance": 3.5,
            "output_format": "png",
            "output_quality": 90,
            "go_fast": True,
        }
    }

    async with httpx.AsyncClient(timeout=120) as client:
        # Запускаем prediction
        resp = await client.post(
            "https://api.replicate.com/v1/predictions",
            headers=headers,
            json=payload
        )
        resp.raise_for_status()
        prediction = resp.json()
        prediction_id = prediction["id"]

        # Поллинг результата
        for _ in range(60):
            await asyncio.sleep(2)
            poll = await client.get(
                f"https://api.replicate.com/v1/predictions/{prediction_id}",
                headers=headers
            )
            data = poll.json()

            if data["status"] == "succeeded":
                return data["output"][0] if data["output"] else None
            elif data["status"] == "failed":
                logger.error(f"Replicate failed: {data.get('error')}")
                return None

    return None


async def generate_from_photo(image_url: str, style_index: int = 0) -> str | None:
    """
    Генерирует эмодзи-стиль на основе загруженного фото (img2img).
    """
    style = EMOJI_STYLES[style_index % len(EMOJI_STYLES)]

    headers = {
        "Authorization": f"Token {config.REPLICATE_API_TOKEN}",
        "Content-Type": "application/json",
    }

    # img2img через flux-dev
    payload = {
        "version": "black-forest-labs/flux-dev",
        "input": {
            "prompt": f"emoji style character, {style}",
            "image": image_url,
            "strength": 0.75,
            "num_inference_steps": 28,
            "guidance": 3.5,
            "output_format": "png",
            "go_fast": True,
        }
    }

    async with httpx.AsyncClient(timeout=120) as client:
        resp = await client.post(
            "https://api.replicate.com/v1/predictions",
            headers=headers,
            json=payload
        )
        resp.raise_for_status()
        prediction = resp.json()
        prediction_id = prediction["id"]

        for _ in range(60):
            await asyncio.sleep(2)
            poll = await client.get(
                f"https://api.replicate.com/v1/predictions/{prediction_id}",
                headers=headers
            )
            data = poll.json()

            if data["status"] == "succeeded":
                return data["output"][0] if data["output"] else None
            elif data["status"] == "failed":
                logger.error(f"Replicate img2img failed: {data.get('error')}")
                return None

    return None


def get_random_combo() -> tuple[str, str, str]:
    """Случайная пресетная комбинация."""
    return random.choice(UNUSUAL_COMBOS)


def build_combo_prompt(emoji1: str, emoji2: str) -> str:
    """Строит промпт для необычной комбинации двух эмодзи."""
    return f"fusion of {emoji1} and {emoji2}, creative emoji mashup, unique combination, artistic style"
