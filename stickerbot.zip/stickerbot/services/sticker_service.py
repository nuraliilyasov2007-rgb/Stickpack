import io
import logging
from PIL import Image

logger = logging.getLogger(__name__)

# Telegram требует стикеры 512x512 PNG с прозрачным фоном
STICKER_SIZE = (512, 512)


def remove_background(image_bytes: bytes) -> bytes:
    """Убирает фон и возвращает PNG с прозрачностью."""
    try:
        from rembg import remove
        input_image = Image.open(io.BytesIO(image_bytes)).convert("RGBA")
        output_image = remove(input_image)
        return _to_sticker_bytes(output_image)
    except Exception as e:
        logger.error(f"rembg ошибка: {e}")
        raise


def _to_sticker_bytes(img: Image.Image) -> bytes:
    """Масштабирует до 512x512, сохраняет пропорции, добавляет паддинг."""
    img.thumbnail(STICKER_SIZE, Image.LANCZOS)

    # Создаём прозрачный холст 512x512
    canvas = Image.new("RGBA", STICKER_SIZE, (0, 0, 0, 0))
    offset = (
        (STICKER_SIZE[0] - img.width) // 2,
        (STICKER_SIZE[1] - img.height) // 2
    )
    canvas.paste(img, offset, img if img.mode == "RGBA" else None)

    buf = io.BytesIO()
    canvas.save(buf, format="PNG")
    buf.seek(0)
    return buf.read()


def image_to_sticker_pack(image_bytes: bytes, count: int = 3) -> list[bytes]:
    """
    Создаёт набор стикеров из одного фото.
    count — сколько вариаций сгенерировать (разные кадры/обрезки).
    """
    stickers = []

    try:
        from rembg import remove
        input_image = Image.open(io.BytesIO(image_bytes)).convert("RGBA")
        output_image = remove(input_image)

        # Основной стикер — полный объект
        stickers.append(_to_sticker_bytes(output_image))

        # Вариация 2 — обрезанная верхняя часть (голова/лицо)
        if count >= 2:
            h = output_image.height
            top_crop = output_image.crop((0, 0, output_image.width, int(h * 0.6)))
            stickers.append(_to_sticker_bytes(top_crop))

        # Вариация 3 — немного повёрнутый
        if count >= 3:
            rotated = output_image.rotate(15, expand=True)
            stickers.append(_to_sticker_bytes(rotated))

        # Если нужно больше — дополнительные трансформации
        if count >= 4:
            flipped = output_image.transpose(Image.FLIP_LEFT_RIGHT)
            stickers.append(_to_sticker_bytes(flipped))

        if count >= 5:
            rotated2 = output_image.rotate(-15, expand=True)
            stickers.append(_to_sticker_bytes(rotated2))

    except Exception as e:
        logger.error(f"Ошибка создания стикерпака: {e}")
        raise

    return stickers[:count]
