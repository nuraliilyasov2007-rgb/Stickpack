import io
import logging
import asyncio
from aiogram import Router, F
from aiogram.types import Message, BufferedInputFile, InlineKeyboardMarkup, InlineKeyboardButton

from database.db import get_today_usage, increment_usage, is_premium
from services.sticker_service import image_to_sticker_pack
from config import config

router = Router()
logger = logging.getLogger(__name__)


def buy_premium_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⭐ Купить премиум", callback_data="show_premium")]
    ])


@router.message(F.photo)
async def handle_photo(message: Message):
    user_id = message.from_user.id
    premium = await is_premium(user_id)
    usage = await get_today_usage(user_id)

    # Проверка лимита
    if not premium and usage["stickers"] >= config.FREE_STICKERS_PER_DAY:
        await message.answer(
            f"😔 Дневной лимит исчерпан!\n\n"
            f"Бесплатно: {config.FREE_STICKERS_PER_DAY} стикера в день\n"
            f"Купи премиум — получишь до 50 стикеров в день + HD качество!",
            reply_markup=buy_premium_kb()
        )
        return

    # Определяем сколько стикеров делать
    sticker_count = 5 if premium else 3

    processing_msg = await message.answer("⏳ Вырезаю объект... это займёт 10-20 секунд")

    try:
        # Скачиваем фото в максимальном качестве
        photo = message.photo[-1]
        file = await message.bot.get_file(photo.file_id)
        file_bytes = await message.bot.download_file(file.file_path)
        image_bytes = file_bytes.read()

        # Запускаем rembg в thread pool (CPU-задача)
        loop = asyncio.get_event_loop()
        stickers = await loop.run_in_executor(
            None,
            image_to_sticker_pack,
            image_bytes,
            sticker_count
        )

        await processing_msg.delete()

        quality_tag = "⭐ HD" if premium else "🆓"
        await message.answer(
            f"✅ Готово! {quality_tag} Вот твои {len(stickers)} стикера(ов):\n"
            f"Сохрани их — можешь использовать в любом чате!"
        )

        # Отправляем стикеры как документы (PNG) — пользователь сохранит
        for i, sticker_bytes in enumerate(stickers, 1):
            sticker_file = BufferedInputFile(
                sticker_bytes,
                filename=f"sticker_{i}.png"
            )
            await message.answer_document(
                sticker_file,
                caption=f"Стикер {i}/{len(stickers)} 🎭"
            )
            await asyncio.sleep(0.3)  # небольшая пауза между файлами

        await increment_usage(user_id, "stickers_used")

        # Подсказка если не премиум
        if not premium:
            remaining = config.FREE_STICKERS_PER_DAY - usage["stickers"] - 1
            if remaining > 0:
                await message.answer(
                    f"💡 Осталось бесплатных запросов сегодня: <b>{remaining}</b>\n"
                    f"Хочешь больше? → /premium",
                    parse_mode="HTML"
                )
            else:
                await message.answer(
                    "💡 Это был последний бесплатный стикер сегодня.\n"
                    "Купи премиум → /premium",
                    reply_markup=buy_premium_kb()
                )

    except Exception as e:
        logger.error(f"Ошибка обработки фото user={user_id}: {e}")
        await processing_msg.delete()
        await message.answer(
            "❌ Что-то пошло не так при обработке фото.\n"
            "Попробуй другую картинку — лучше всего работает с чёткими объектами на контрастном фоне."
        )


@router.message(F.document & F.document.mime_type.startswith("image/"))
async def handle_document_image(message: Message):
    """Если прислали картинку как файл а не как фото."""
    user_id = message.from_user.id
    premium = await is_premium(user_id)
    usage = await get_today_usage(user_id)

    if not premium and usage["stickers"] >= config.FREE_STICKERS_PER_DAY:
        await message.answer(
            "😔 Дневной лимит исчерпан! Купи премиум → /premium",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="⭐ Премиум", callback_data="show_premium")]
            ])
        )
        return

    processing_msg = await message.answer("⏳ Обрабатываю файл...")

    try:
        file = await message.bot.get_file(message.document.file_id)
        file_bytes = await message.bot.download_file(file.file_path)
        image_bytes = file_bytes.read()

        sticker_count = 5 if premium else 3
        loop = asyncio.get_event_loop()
        stickers = await loop.run_in_executor(
            None, image_to_sticker_pack, image_bytes, sticker_count
        )

        await processing_msg.delete()
        await message.answer(f"✅ Готово! {len(stickers)} стикера(ов):")

        for i, sticker_bytes in enumerate(stickers, 1):
            sticker_file = BufferedInputFile(sticker_bytes, filename=f"sticker_{i}.png")
            await message.answer_document(sticker_file, caption=f"Стикер {i}/{len(stickers)} 🎭")
            await asyncio.sleep(0.3)

        await increment_usage(user_id, "stickers_used")

    except Exception as e:
        logger.error(f"Ошибка документа user={user_id}: {e}")
        await processing_msg.delete()
        await message.answer("❌ Не удалось обработать файл. Попробуй отправить как фото.")
