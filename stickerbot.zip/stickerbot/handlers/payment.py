import logging
from aiogram import Router, F
from aiogram.types import (
    Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton,
    LabeledPrice, PreCheckoutQuery
)
from aiogram.filters import Command

from database.db import is_premium, log_payment, set_premium
from config import config

router = Router()
logger = logging.getLogger(__name__)

# Продукты
PRODUCTS = {
    "full_pack": {
        "title": "⭐ Полный стикерпак",
        "description": "До 50 стикеров HD качества из одного фото",
        "stars": config.PRICE_FULL_PACK,
        "payload": "full_pack",
    },
    "emoji_month": {
        "title": "✨ Эмодзи безлимит (30 дней)",
        "description": "Безлимитная генерация эмодзи + все стили",
        "stars": config.PRICE_EMOJI_UNLIMITED,
        "payload": "emoji_month",
    },
    "premium_month": {
        "title": "🌟 Полный Премиум (30 дней)",
        "description": "Всё включено: HD стикеры + эмодзи безлимит + приоритет",
        "stars": 75,
        "payload": "premium_month",
    },
}


def premium_shop_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text=f"🎭 Полный стикерпак — {PRODUCTS['full_pack']['stars']} ⭐",
            callback_data="buy:full_pack"
        )],
        [InlineKeyboardButton(
            text=f"✨ Эмодзи безлимит — {PRODUCTS['emoji_month']['stars']} ⭐",
            callback_data="buy:emoji_month"
        )],
        [InlineKeyboardButton(
            text=f"🌟 Полный Премиум — {PRODUCTS['premium_month']['stars']} ⭐",
            callback_data="buy:premium_month"
        )],
        [InlineKeyboardButton(text="❓ Что такое Stars?", callback_data="stars_info")],
    ])


@router.message(Command("premium"))
async def cmd_premium(message: Message):
    await show_premium(message)


@router.callback_query(F.data == "show_premium")
async def cb_show_premium(callback: CallbackQuery):
    await show_premium(callback.message)
    await callback.answer()


async def show_premium(message: Message):
    premium = await is_premium(message.chat.id)

    if premium:
        await message.answer(
            "⭐ <b>У тебя уже есть Премиум!</b>\n\n"
            "Наслаждайся:\n"
            "✅ HD стикеры (до 50 шт)\n"
            "✅ Безлимитные эмодзи\n"
            "✅ Все стили генерации\n"
            "✅ Приоритетная обработка",
            parse_mode="HTML"
        )
        return

    await message.answer(
        "🌟 <b>Премиум возможности</b>\n\n"
        "🎭 <b>Полный стикерпак</b> — 50 ⭐\n"
        "До 50 HD стикеров из одного фото\n\n"
        "✨ <b>Эмодзи безлимит</b> — 30 ⭐\n"
        "Безлимит на 30 дней + все стили\n\n"
        "🌟 <b>Полный Премиум</b> — 75 ⭐\n"
        "Всё включено на 30 дней!\n\n"
        "💡 <i>Оплата через Telegram Stars — безопасно и мгновенно</i>",
        parse_mode="HTML",
        reply_markup=premium_shop_kb()
    )


@router.callback_query(F.data == "stars_info")
async def cb_stars_info(callback: CallbackQuery):
    await callback.message.answer(
        "💫 <b>Telegram Stars</b>\n\n"
        "Stars — встроенная валюта Telegram.\n"
        "Купить можно прямо в приложении:\n"
        "Настройки → Telegram Stars\n\n"
        "Оплата безопасна и мгновенна 🔒",
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data.startswith("buy:"))
async def cb_buy(callback: CallbackQuery):
    product_key = callback.data.split(":")[1]
    product = PRODUCTS.get(product_key)

    if not product:
        await callback.answer("❌ Продукт не найден", show_alert=True)
        return

    await callback.message.bot.send_invoice(
        chat_id=callback.from_user.id,
        title=product["title"],
        description=product["description"],
        payload=product["payload"],
        currency="XTR",  # Telegram Stars
        prices=[LabeledPrice(label=product["title"], amount=product["stars"])],
        provider_token="",  # Пустой для Stars
    )
    await callback.answer()


@router.pre_checkout_query()
async def pre_checkout(query: PreCheckoutQuery):
    """Подтверждаем любой платёж."""
    await query.answer(ok=True)


@router.message(F.successful_payment)
async def successful_payment(message: Message):
    """Обрабатываем успешную оплату."""
    payment = message.successful_payment
    user_id = message.from_user.id
    payload = payment.invoice_payload

    stars_paid = payment.total_amount

    await log_payment(user_id, payload, stars_paid)

    if payload == "full_pack":
        # Разовая покупка — не нужно premium флаг
        await message.answer(
            "🎉 <b>Оплата получена!</b>\n\n"
            "🎭 Отправь фото — сделаю полный HD стикерпак (до 50 шт)!\n"
            f"Потрачено: {stars_paid} ⭐",
            parse_mode="HTML"
        )

    elif payload == "emoji_month":
        await set_premium(user_id, days=30)
        await message.answer(
            "🎉 <b>Эмодзи Премиум активирован!</b>\n\n"
            "✨ Безлимитная генерация эмодзи на 30 дней\n"
            "🎨 Все стили доступны\n\n"
            f"Потрачено: {stars_paid} ⭐\n"
            "Попробуй: /emoji_random",
            parse_mode="HTML"
        )

    elif payload == "premium_month":
        await set_premium(user_id, days=30)
        await message.answer(
            "🌟 <b>Полный Премиум активирован!</b>\n\n"
            "✅ До 50 HD стикеров из фото\n"
            "✅ Безлимит эмодзи + все стили\n"
            "✅ Приоритетная обработка\n\n"
            f"Потрачено: {stars_paid} ⭐\n"
            "Срок: 30 дней 🎊",
            parse_mode="HTML"
        )

    logger.info(f"Оплата: user={user_id} product={payload} stars={stars_paid}")
