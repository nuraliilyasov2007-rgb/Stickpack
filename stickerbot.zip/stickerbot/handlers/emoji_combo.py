import logging
import httpx
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import Command

from database.db import get_today_usage, increment_usage, is_premium
from services.emoji_service import (
    generate_emoji_combo, generate_from_photo,
    get_random_combo, build_combo_prompt, EMOJI_STYLES
)
from config import config

router = Router()
logger = logging.getLogger(__name__)


def style_kb(prompt: str) -> InlineKeyboardMarkup:
    """Кнопки выбора стиля (только для премиум)."""
    styles = ["Flat", "Kawaii", "Neon", "Watercolor", "3D"]
    buttons = [
        InlineKeyboardButton(
            text=name,
            callback_data=f"emoji_style:{i}:{prompt[:30]}"
        )
        for i, name in enumerate(styles)
    ]
    return InlineKeyboardMarkup(inline_keyboard=[buttons[:3], buttons[3:]])


def buy_premium_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⭐ Купить премиум", callback_data="show_premium")]
    ])


@router.message(Command("emoji"))
async def cmd_emoji(message: Message):
    user_id = message.from_user.id
    premium = await is_premium(user_id)
    usage = await get_today_usage(user_id)

    if not premium and usage["emoji"] >= config.FREE_EMOJI_PER_DAY:
        await message.answer(
            f"😔 Дневной лимит: {config.FREE_EMOJI_PER_DAY} генераций исчерпан!\n"
            "Купи премиум → /premium",
            reply_markup=buy_premium_kb()
        )
        return

    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.answer(
            "❓ Использование:\n"
            "<code>/emoji 🕯️ + 🦩</code> — слияние двух эмодзи\n"
            "<code>/emoji канделябр</code> — по описанию\n"
            "<code>/emoji_random</code> — случайное",
            parse_mode="HTML"
        )
        return

    query = args[1].strip()

    # Парсим формат "🕯️ + 🦩"
    if "+" in query:
        parts = [p.strip() for p in query.split("+")]
        if len(parts) == 2:
            prompt = build_combo_prompt(parts[0], parts[1])
            display = f"{parts[0]} + {parts[1]}"
        else:
            prompt = query
            display = query
    else:
        prompt = query
        display = query

    processing_msg = await message.answer(f"🎨 Генерирую: <b>{display}</b>\n⏳ ~30 секунд...", parse_mode="HTML")

    try:
        image_url = await generate_emoji_combo(prompt)

        if not image_url:
            await processing_msg.edit_text("❌ Не удалось сгенерировать. Попробуй другой запрос.")
            return

        # Скачиваем и отправляем
        async with httpx.AsyncClient() as client:
            resp = await client.get(image_url)
            img_bytes = resp.content

        await processing_msg.delete()

        from aiogram.types import BufferedInputFile
        img_file = BufferedInputFile(img_bytes, filename="emoji_combo.png")

        style_text = "\n✨ <b>Премиум:</b> выбери стиль 👇" if premium else f"\n🆓 Осталось генераций: {config.FREE_EMOJI_PER_DAY - usage['emoji'] - 1}"

        await message.answer_photo(
            img_file,
            caption=f"✅ <b>{display}</b>{style_text}",
            parse_mode="HTML",
            reply_markup=style_kb(prompt) if premium else None
        )

        await increment_usage(user_id, "emoji_used")

    except Exception as e:
        logger.error(f"Ошибка генерации эмодзи user={user_id}: {e}")
        await processing_msg.edit_text("❌ Ошибка при генерации. Попробуй позже.")


@router.message(Command("emoji_random"))
async def cmd_emoji_random(message: Message):
    user_id = message.from_user.id
    premium = await is_premium(user_id)
    usage = await get_today_usage(user_id)

    if not premium and usage["emoji"] >= config.FREE_EMOJI_PER_DAY:
        await message.answer(
            "😔 Лимит исчерпан! → /premium",
            reply_markup=buy_premium_kb()
        )
        return

    emoji, name_ru, prompt = get_random_combo()
    processing_msg = await message.answer(
        f"🎲 Случайная комбинация: <b>{emoji} {name_ru}</b>\n⏳ Генерирую...",
        parse_mode="HTML"
    )

    try:
        image_url = await generate_emoji_combo(prompt)

        if not image_url:
            await processing_msg.edit_text("❌ Не удалось сгенерировать. Попробуй ещё раз!")
            return

        async with httpx.AsyncClient() as client:
            resp = await client.get(image_url)
            img_bytes = resp.content

        await processing_msg.delete()

        from aiogram.types import BufferedInputFile
        img_file = BufferedInputFile(img_bytes, filename="emoji_random.png")

        await message.answer_photo(
            img_file,
            caption=f"✅ <b>{emoji} {name_ru}</b>\n\n/emoji_random — ещё одно случайное!",
            parse_mode="HTML"
        )

        await increment_usage(user_id, "emoji_used")

    except Exception as e:
        logger.error(f"Ошибка random эмодзи user={user_id}: {e}")
        await processing_msg.edit_text("❌ Ошибка. Попробуй ещё раз.")


@router.callback_query(F.data.startswith("emoji_style:"))
async def cb_emoji_style(callback: CallbackQuery):
    """Смена стиля (только премиум)."""
    premium = await is_premium(callback.from_user.id)
    if not premium:
        await callback.answer("⭐ Это премиум функция!", show_alert=True)
        return

    parts = callback.data.split(":", 2)
    style_index = int(parts[1])
    prompt = parts[2]

    await callback.answer("🎨 Перегенерирую в новом стиле...")

    try:
        image_url = await generate_emoji_combo(prompt, style_index)

        if not image_url:
            await callback.message.answer("❌ Не удалось. Попробуй другой стиль.")
            return

        async with httpx.AsyncClient() as client:
            resp = await client.get(image_url)
            img_bytes = resp.content

        from aiogram.types import BufferedInputFile
        style_names = ["Flat", "Kawaii", "Neon", "Watercolor", "3D"]
        img_file = BufferedInputFile(img_bytes, filename="emoji_restyled.png")

        await callback.message.answer_photo(
            img_file,
            caption=f"🎨 Стиль: <b>{style_names[style_index]}</b>",
            parse_mode="HTML",
            reply_markup=style_kb(prompt)
        )

    except Exception as e:
        logger.error(f"Ошибка смены стиля: {e}")
        await callback.message.answer("❌ Ошибка при смене стиля.")
