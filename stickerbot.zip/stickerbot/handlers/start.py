from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import CommandStart, Command

from database.db import get_or_create_user, is_premium, get_today_usage
from config import config

router = Router()


def main_menu_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🎭 Создать стикерпак", callback_data="make_stickers"),
            InlineKeyboardButton(text="✨ Эмодзи-комбо", callback_data="make_emoji"),
        ],
        [
            InlineKeyboardButton(text="🌟 Премиум", callback_data="show_premium"),
            InlineKeyboardButton(text="📊 Мой баланс", callback_data="my_stats"),
        ],
        [
            InlineKeyboardButton(text="❓ Помощь", callback_data="help"),
        ]
    ])


@router.message(CommandStart())
async def cmd_start(message: Message):
    user = message.from_user
    await get_or_create_user(user.id, user.username or "", user.first_name or "")

    premium = await is_premium(user.id)
    status = "⭐ Премиум" if premium else "🆓 Бесплатный"

    await message.answer(
        f"👋 Привет, <b>{user.first_name}</b>!\n\n"
        f"Я умею:\n"
        f"🎭 <b>Стикерпак из фото</b> — отправь картинку, я вырежу объект и сделаю стикеры\n"
        f"✨ <b>Эмодзи-комбо</b> — генерирую необычные эмодзи которых нет в стандартных\n"
        f"🎨 <b>Канделябр-стиль</b> — всякие странные и крутые комбинации\n\n"
        f"Статус: {status}\n\n"
        f"Выбирай что делаем 👇",
        parse_mode="HTML",
        reply_markup=main_menu_kb()
    )


@router.callback_query(F.data == "make_stickers")
async def cb_make_stickers(callback: CallbackQuery):
    await callback.message.answer(
        "🎭 <b>Создание стикерпака</b>\n\n"
        "Просто отправь мне фотографию — я вырежу главный объект и сделаю стикеры!\n\n"
        "🆓 Бесплатно: <b>3 стикера в день</b>\n"
        "⭐ Премиум: <b>до 50 стикеров, HD качество</b>\n\n"
        "📸 Жду фотку!",
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data == "make_emoji")
async def cb_make_emoji(callback: CallbackQuery):
    await callback.message.answer(
        "✨ <b>Генерация эмодзи-комбо</b>\n\n"
        "Отправь команду в формате:\n"
        "<code>/emoji 🕯️ + 🦩</code> — сгенерирую слияние двух эмодзи\n"
        "<code>/emoji канделябр</code> — генерирую по описанию\n"
        "<code>/emoji_random</code> — случайная необычная комбинация\n\n"
        "🆓 Бесплатно: <b>5 генераций в день</b>\n"
        "⭐ Премиум: <b>безлимит + больше стилей</b>",
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data == "my_stats")
async def cb_my_stats(callback: CallbackQuery):
    user_id = callback.from_user.id
    usage = await get_today_usage(user_id)
    premium = await is_premium(user_id)

    sticker_limit = "∞" if premium else config.FREE_STICKERS_PER_DAY
    emoji_limit = "∞" if premium else config.FREE_EMOJI_PER_DAY

    await callback.message.answer(
        f"📊 <b>Статистика сегодня</b>\n\n"
        f"🎭 Стикеры: {usage['stickers']} / {sticker_limit}\n"
        f"✨ Эмодзи: {usage['emoji']} / {emoji_limit}\n\n"
        f"Статус: {'⭐ Премиум' if premium else '🆓 Бесплатный'}",
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data == "help")
async def cb_help(callback: CallbackQuery):
    await callback.message.answer(
        "❓ <b>Как пользоваться</b>\n\n"
        "1️⃣ Отправь фото → получишь стикеры с вырезанным объектом\n"
        "2️⃣ <code>/emoji 🌙 + 🔮</code> → эмодзи-слияние\n"
        "3️⃣ <code>/emoji_random</code> → случайная крутая комбинация\n"
        "4️⃣ <code>/premium</code> → купить премиум за Stars\n\n"
        "🔧 <b>Команды:</b>\n"
        "/start — главное меню\n"
        "/emoji — генерация эмодзи\n"
        "/emoji_random — случайное комбо\n"
        "/premium — купить премиум\n"
        "/stats — моя статистика",
        parse_mode="HTML"
    )
    await callback.answer()
